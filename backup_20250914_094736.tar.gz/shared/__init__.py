"""
Shared components for Agent Lightning
This module contains shared database models, cache management, and utilities
used across all microservices.
"""

__version__ = "1.0.0"