"""
Database models for Agent Lightning
Using SQLAlchemy ORM for PostgreSQL database
"""

from sqlalchemy import Column, String, Integer, JSON, DateTime, Text, Float, ForeignKey, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.sql import func
from datetime import datetime
import uuid

Base = declarative_base()

class Agent(Base):
    """Agent model - represents AI agents in the system"""
    __tablename__ = 'agents'
    
    id = Column(String(50), primary_key=True)
    name = Column(String(100), nullable=False)
    model = Column(String(50), nullable=False)
    specialization = Column(String(50))
    status = Column(String(20), default='idle')
    config = Column(JSONB, default={})
    capabilities = Column(JSONB, default=[])
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    def to_dict(self):
        """Convert agent to dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'model': self.model,
            'specialization': self.specialization,
            'status': self.status,
            'config': self.config,
            'capabilities': self.capabilities,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Task(Base):
    """Task model - represents tasks assigned to agents"""
    __tablename__ = 'tasks'
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    agent_id = Column(String(50), ForeignKey('agents.id', ondelete='CASCADE'))
    description = Column(Text)
    status = Column(String(20), default='pending')
    priority = Column(String(20), default='normal')
    context = Column(JSONB, default={})
    result = Column(JSONB)
    error_message = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    started_at = Column(DateTime(timezone=True))
    completed_at = Column(DateTime(timezone=True))
    
    def to_dict(self):
        """Convert task to dictionary"""
        return {
            'id': str(self.id),
            'agent_id': self.agent_id,
            'description': self.description,
            'status': self.status,
            'priority': self.priority,
            'context': self.context,
            'result': self.result,
            'error_message': self.error_message,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None
        }

class Knowledge(Base):
    """Knowledge model - stores agent learning and knowledge base"""
    __tablename__ = 'knowledge'
    
    id = Column(String(255), primary_key=True)
    agent_id = Column(String(50), ForeignKey('agents.id', ondelete='CASCADE'))
    category = Column(String(50))
    content = Column(Text)
    source = Column(Text)
    meta_data = Column('metadata', JSONB, default={})
    usage_count = Column(Integer, default=0)
    relevance_score = Column(Float, default=1.0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    last_used_at = Column(DateTime(timezone=True))
    
    # Note: Vector embedding field would be added with pgvector extension
    # embedding = Column(Vector(1536))  # For similarity search
    
    def to_dict(self):
        """Convert knowledge to dictionary"""
        return {
            'id': self.id,
            'agent_id': self.agent_id,
            'category': self.category,
            'content': self.content,
            'source': self.source,
            'metadata': self.meta_data,
            'usage_count': self.usage_count,
            'relevance_score': self.relevance_score,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_used_at': self.last_used_at.isoformat() if self.last_used_at else None
        }

class Workflow(Base):
    """Workflow model - complex task orchestration"""
    __tablename__ = 'workflows'
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(100))
    description = Column(Text)
    steps = Column(JSONB)
    status = Column(String(20), default='draft')
    created_by = Column(String(50))
    assigned_to = Column(String(50))
    context = Column(JSONB, default={})
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    def to_dict(self):
        """Convert workflow to dictionary"""
        return {
            'id': str(self.id),
            'name': self.name,
            'description': self.description,
            'steps': self.steps,
            'status': self.status,
            'created_by': self.created_by,
            'assigned_to': self.assigned_to,
            'context': self.context,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Session(Base):
    """Session model - user session management"""
    __tablename__ = 'sessions'
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(String(100))
    token = Column(String(500), unique=True, index=True)
    data = Column(JSONB, default={})
    expires_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    def to_dict(self):
        """Convert session to dictionary"""
        return {
            'id': str(self.id),
            'user_id': self.user_id,
            'token': self.token,
            'data': self.data,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def is_expired(self):
        """Check if session is expired"""
        if not self.expires_at:
            return False
        return datetime.utcnow() > self.expires_at

class Metric(Base):
    """Metric model - performance and monitoring data"""
    __tablename__ = 'metrics'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    service_name = Column(String(50), index=True)
    metric_name = Column(String(100), index=True)
    value = Column(Float)
    tags = Column(JSONB, default={})
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    
    def to_dict(self):
        """Convert metric to dictionary"""
        return {
            'id': self.id,
            'service_name': self.service_name,
            'metric_name': self.metric_name,
            'value': self.value,
            'tags': self.tags,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None
        }

class Conversation(Base):
    """Conversation model - stores all Q&A for knowledge gathering"""
    __tablename__ = 'conversations'
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    task_id = Column(String(255), index=True)
    agent_id = Column(String(50), ForeignKey('agents.id', ondelete='CASCADE'), index=True)
    user_query = Column(Text, nullable=False)
    agent_response = Column(Text, nullable=False)
    context = Column(JSONB, default={})
    metadata = Column(JSONB, default={})
    success = Column(Boolean, default=True)
    knowledge_used = Column(Integer, default=0)
    rl_enhanced = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    
    def to_dict(self):
        """Convert conversation to dictionary"""
        return {
            'id': str(self.id),
            'task_id': self.task_id,
            'agent_id': self.agent_id,
            'user_query': self.user_query,
            'agent_response': self.agent_response,
            'context': self.context,
            'metadata': self.metadata,
            'success': self.success,
            'knowledge_used': self.knowledge_used,
            'rl_enhanced': self.rl_enhanced,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class User(Base):
    """User model - system users"""
    __tablename__ = 'users'
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(100), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), default='user')
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    def to_dict(self):
        """Convert user to dictionary (without password)"""
        return {
            'id': str(self.id),
            'username': self.username,
            'email': self.email,
            'role': self.role,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }