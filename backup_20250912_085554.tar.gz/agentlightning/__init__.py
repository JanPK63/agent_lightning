__version__ = "0.1.2"

from .client import AgentLightningClient, DevTaskLoader
from .config import lightning_cli
from .litagent import LitAgent
from .logging import configure_logger
from .reward import reward
from .server import AgentLightningServer
from .trainer import Trainer
from .types import *

# RL Orchestrator integration
try:
    import sys
    from pathlib import Path
    sys.path.append(str(Path(__file__).parent.parent / 'rl_orch'))
    from rl_orch.core.orchestrator import RLOrchestrator
    from rl_orch.core.config_models import ExperimentConfig
    RL_AVAILABLE = True
except ImportError:
    RL_AVAILABLE = False
    RLOrchestrator = None
    ExperimentConfig = None
