"""
LangChain Tools Framework for Agent Lightning
Provides tools for code execution, web search, file operations, and database queries
"""

import subprocess
import requests
import json
import os
from typing import Dict, Any, Optional, List
from langchain.tools import Tool, BaseTool
from langchain_core.tools import tool
from pydantic import BaseModel, Field

# Import existing services
from web_search_tool import search_web as web_search_function
from shared.database import db_manager
from shared.models import Agent, Task, Knowledge


class CodeExecutionInput(BaseModel):
    """Input for code execution tool"""
    code: str = Field(description="Python code to execute")
    language: str = Field(default="python", description="Programming language")


class WebSearchInput(BaseModel):
    """Input for web search tool"""
    query: str = Field(description="Search query")
    num_results: int = Field(default=5, description="Number of results to return")


class FileOperationInput(BaseModel):
    """Input for file operations"""
    operation: str = Field(description="Operation: read, write, list, delete")
    path: str = Field(description="File or directory path")
    content: Optional[str] = Field(default=None, description="Content for write operations")


class DatabaseQueryInput(BaseModel):
    """Input for database queries"""
    query_type: str = Field(description="Query type: agents, tasks, knowledge")
    filters: Optional[Dict[str, Any]] = Field(default=None, description="Query filters")


@tool
def execute_python_code(code: str) -> str:
    """
    Execute Python code safely and return the output.
    
    Args:
        code: Python code to execute
        
    Returns:
        Execution output or error message
    """
    try:
        # Create a safe execution environment
        result = subprocess.run(
            ["python", "-c", code],
            capture_output=True,
            text=True,
            timeout=30,
            cwd="/tmp"
        )
        
        if result.returncode == 0:
            return f"✅ Code executed successfully:\n{result.stdout}"
        else:
            return f"❌ Code execution failed:\n{result.stderr}"
            
    except subprocess.TimeoutExpired:
        return "❌ Code execution timed out (30s limit)"
    except Exception as e:
        return f"❌ Execution error: {str(e)}"


@tool
def search_web(query: str, num_results: int = 5) -> str:
    """
    Search the web for information.
    
    Args:
        query: Search query
        num_results: Number of results to return
        
    Returns:
        Search results as formatted text
    """
    try:
        results = web_search_function(query, num_results)
        return f"🔍 {results}"
        
    except Exception as e:
        return f"❌ Web search failed: {str(e)}"


@tool
def read_file(path: str) -> str:
    """
    Read content from a file.
    
    Args:
        path: File path to read
        
    Returns:
        File content or error message
    """
    try:
        # Security check - only allow reading from safe directories
        safe_dirs = ["/tmp", "/Users/jankootstra/agent-lightning-main"]
        if not any(os.path.abspath(path).startswith(safe_dir) for safe_dir in safe_dirs):
            return "❌ Access denied: File not in allowed directories"
        
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        return f"📄 File content ({len(content)} chars):\n{content[:2000]}{'...' if len(content) > 2000 else ''}"
        
    except FileNotFoundError:
        return f"❌ File not found: {path}"
    except Exception as e:
        return f"❌ Error reading file: {str(e)}"


@tool
def write_file(path: str, content: str) -> str:
    """
    Write content to a file.
    
    Args:
        path: File path to write
        content: Content to write
        
    Returns:
        Success or error message
    """
    try:
        # Security check - only allow writing to safe directories
        safe_dirs = ["/tmp", "/Users/jankootstra/agent-lightning-main"]
        if not any(os.path.abspath(path).startswith(safe_dir) for safe_dir in safe_dirs):
            return "❌ Access denied: Cannot write to this directory"
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(path), exist_ok=True)
        
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return f"✅ File written successfully: {path} ({len(content)} chars)"
        
    except Exception as e:
        return f"❌ Error writing file: {str(e)}"


@tool
def list_directory(path: str) -> str:
    """
    List contents of a directory.
    
    Args:
        path: Directory path to list
        
    Returns:
        Directory contents or error message
    """
    try:
        # Security check
        safe_dirs = ["/tmp", "/Users/jankootstra/agent-lightning-main"]
        if not any(os.path.abspath(path).startswith(safe_dir) for safe_dir in safe_dirs):
            return "❌ Access denied: Directory not in allowed paths"
        
        items = os.listdir(path)
        if not items:
            return f"📁 Directory is empty: {path}"
        
        result = f"📁 Directory contents ({len(items)} items):\n"
        for item in sorted(items):
            item_path = os.path.join(path, item)
            if os.path.isdir(item_path):
                result += f"  📁 {item}/\n"
            else:
                size = os.path.getsize(item_path)
                result += f"  📄 {item} ({size} bytes)\n"
        
        return result
        
    except FileNotFoundError:
        return f"❌ Directory not found: {path}"
    except Exception as e:
        return f"❌ Error listing directory: {str(e)}"


@tool
def query_agents(filters: str = "{}") -> str:
    """
    Query agents from the database.
    
    Args:
        filters: JSON string with query filters (e.g., '{"name": "test"}')
        
    Returns:
        Agent information or error message
    """
    try:
        filter_dict = json.loads(filters) if filters != "{}" else {}
        
        with db_manager.get_db() as db:
            query = db.query(Agent)
            
            # Apply filters
            if "name" in filter_dict:
                query = query.filter(Agent.name.ilike(f"%{filter_dict['name']}%"))
            if "model" in filter_dict:
                query = query.filter(Agent.model == filter_dict['model'])
            
            agents = query.limit(10).all()
            
            if not agents:
                return "No agents found matching the criteria."
            
            result = f"🤖 Found {len(agents)} agents:\n\n"
            for agent in agents:
                result += f"• **{agent.name}** (ID: {agent.id})\n"
                result += f"  Model: {agent.model}\n"
                result += f"  Specialization: {agent.specialization or 'None'}\n"
                result += f"  Status: {agent.status}\n\n"
            
            return result
            
    except json.JSONDecodeError:
        return "❌ Invalid JSON in filters parameter"
    except Exception as e:
        return f"❌ Database query failed: {str(e)}"


@tool
def query_knowledge(agent_id: str = "", category: str = "") -> str:
    """
    Query knowledge items from the database.
    
    Args:
        agent_id: Filter by agent ID
        category: Filter by category
        
    Returns:
        Knowledge information or error message
    """
    try:
        with db_manager.get_db() as db:
            query = db.query(Knowledge)
            
            # Apply filters
            if agent_id:
                query = query.filter(Knowledge.agent_id == agent_id)
            if category:
                query = query.filter(Knowledge.category.ilike(f"%{category}%"))
            
            knowledge_items = query.limit(10).all()
            
            if not knowledge_items:
                return "No knowledge items found matching the criteria."
            
            result = f"📚 Found {len(knowledge_items)} knowledge items:\n\n"
            for item in knowledge_items:
                result += f"• **{item.category}** (ID: {item.id})\n"
                result += f"  Agent: {item.agent_id}\n"
                result += f"  Content: {item.content[:100]}{'...' if len(item.content) > 100 else ''}\n"
                result += f"  Relevance: {item.relevance_score}\n\n"
            
            return result
            
    except Exception as e:
        return f"❌ Knowledge query failed: {str(e)}"


class AgentToolsFramework:
    """
    Framework for managing LangChain tools for agents
    """
    
    def __init__(self):
        self.tools = self._create_tools()
    
    def _create_tools(self) -> List[Tool]:
        """Create all available tools"""
        return [
            execute_python_code,
            search_web,
            read_file,
            write_file,
            list_directory,
            query_agents,
            query_knowledge
        ]
    
    def get_tools(self, agent_capabilities: Optional[Dict[str, bool]] = None) -> List[Tool]:
        """
        Get tools based on agent capabilities
        
        Args:
            agent_capabilities: Dict of capabilities (can_write_code, etc.)
            
        Returns:
            List of available tools for the agent
        """
        if not agent_capabilities:
            return self.tools
        
        available_tools = []
        
        # Code execution tools
        if agent_capabilities.get("can_write_code", False):
            available_tools.append(execute_python_code)
        
        # File operation tools
        if agent_capabilities.get("can_write_documentation", False):
            available_tools.extend([read_file, write_file, list_directory])
        
        # Web search tools (always available for internet-enabled agents)
        available_tools.append(search_web)
        
        # Database query tools (always available)
        available_tools.extend([query_agents, query_knowledge])
        
        return available_tools
    
    def get_tool_names(self) -> List[str]:
        """Get list of all tool names"""
        return [tool.name for tool in self.tools]
    
    def get_tool_descriptions(self) -> Dict[str, str]:
        """Get tool descriptions"""
        return {tool.name: tool.description for tool in self.tools}


# Global instance
agent_tools_framework = AgentToolsFramework()


def get_agent_tools(agent_capabilities: Optional[Dict[str, bool]] = None) -> List[Tool]:
    """
    Convenience function to get tools for an agent
    
    Args:
        agent_capabilities: Agent capabilities dict
        
    Returns:
        List of tools
    """
    return agent_tools_framework.get_tools(agent_capabilities)